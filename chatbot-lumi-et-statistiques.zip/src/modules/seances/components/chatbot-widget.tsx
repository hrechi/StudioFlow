"use client";

/**
 * Module : Chatbot IA · Responsable : Yosser Rafrafi
 * Widget flottant du site vitrine. Il ne parle qu'à /api/chat (lecture seule, basé sur les vrais packs).
 * Les packs évoqués s'affichent en CARTES construites par le serveur depuis le catalogue réel :
 * le texte du modèle reste court, les prix et prestations ne passent jamais par lui.
 */

import { Aperture, Check, Clock, RotateCcw, Send, Sparkles, Star, X } from "lucide-react";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { CHATBOT_NAME, CHATBOT_ROLE, type ChatPackCard } from "../chatbot/chatbot.config";

type Msg = { role: "user" | "assistant"; content: string; packs?: ChatPackCard[] };

const SUGGESTIONS = [
  "Quels packs proposez-vous pour un mariage ?",
  "J'ai un budget de 800 TND",
  "Comparez vos packs",
];

const WELCOME = `Bonjour, je suis ${CHATBOT_NAME} ! Je peux vous présenter nos packs, les comparer et vous aider à choisir. Les prix viennent directement des offres actuelles du studio.`;

const MAX_VISIBLE_SERVICES = 5;

function formatPrix(prix: number | null): string {
  return prix === null ? "Prix sur demande" : `${prix.toLocaleString("fr-FR")} TND`;
}

function formatDuree(min: number): string {
  const h = Math.floor(min / 60);
  const m = min % 60;
  return h > 0 ? `${h} h${m ? ` ${String(m).padStart(2, "0")}` : ""}` : `${m} min`;
}

/** Avatar rond du chatbot (objectif photo). */
function Avatar({ className }: { className?: string }) {
  return (
    <span
      aria-hidden
      className={cn(
        "flex shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-ai to-primary text-white",
        className,
      )}
    >
      <Aperture className="size-[55%]" />
    </span>
  );
}

function PackCard({ pack, bookHref }: { pack: ChatPackCard; bookHref: string }) {
  const visible = pack.prestations.slice(0, MAX_VISIBLE_SERVICES);
  const hidden = pack.prestations.length - visible.length;
  return (
    <article
      aria-label={`Pack ${pack.nom}`}
      className="flex w-60 shrink-0 snap-start flex-col rounded-xl border bg-card p-3 shadow-sm"
    >
      <div className="flex items-start justify-between gap-2">
        <p className="min-w-0 truncate text-[0.7rem] font-medium tracking-wide text-muted-foreground uppercase">
          {pack.typeEvenement}
        </p>
        {pack.miseEnAvant && (
          <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-warning/15 px-2 py-0.5 text-[0.65rem] font-semibold text-warning-text">
            <Star className="size-3" aria-hidden /> Populaire
          </span>
        )}
      </div>
      <h3 className="mt-1 text-base font-semibold text-foreground">{pack.nom}</h3>
      <p className="mt-0.5 flex items-baseline gap-2">
        <span
          className={cn(
            "font-bold tabular-nums",
            pack.prix === null ? "text-sm text-muted-foreground" : "text-xl text-foreground",
          )}
        >
          {formatPrix(pack.prix)}
        </span>
        {pack.dureeMinutes !== null && (
          <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
            <Clock className="size-3" aria-hidden /> {formatDuree(pack.dureeMinutes)}
          </span>
        )}
      </p>

      <ul className="mt-3 flex-1 space-y-1.5 border-t pt-3 text-xs text-slate">
        {visible.map((s) => (
          <li key={s.libelle} className="flex items-start gap-2">
            <Check className="mt-0.5 size-3.5 shrink-0 text-success-text" aria-hidden />
            <span>
              {s.libelle}
              {s.conditions && <span className="text-muted-foreground"> ({s.conditions})</span>}
            </span>
          </li>
        ))}
        {hidden > 0 && <li className="pl-5 text-muted-foreground">+ {hidden} autre{hidden > 1 ? "s" : ""}</li>}
      </ul>

      <Button asChild size="sm" className="mt-3 w-full">
        <Link href={`${bookHref}?pack=${pack.id}`}>Demander ce pack</Link>
      </Button>
    </article>
  );
}

function TypingDots() {
  return (
    <div className="flex items-end gap-2" role="status" aria-label={`${CHATBOT_NAME} écrit`}>
      <Avatar className="size-6" />
      <div className="flex gap-1 rounded-2xl rounded-bl-sm bg-muted px-3 py-3">
        {[0, 150, 300].map((d) => (
          <span
            key={d}
            style={{ animationDelay: `${d}ms` }}
            className="size-1.5 rounded-full bg-muted-foreground/60 motion-safe:animate-bounce"
          />
        ))}
      </div>
    </div>
  );
}

export function ChatbotWidget({ bookHref }: { bookHref: string }) {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [pending, setPending] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, pending, open]);

  useEffect(() => {
    if (open) inputRef.current?.focus();
  }, [open]);

  async function send(text: string) {
    const content = text.trim();
    if (!content || pending) return;
    const next: Msg[] = [...messages, { role: "user", content }];
    setMessages(next);
    setInput("");
    setPending(true);
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: next.slice(-10).map(({ role, content: c }) => ({ role, content: c })),
        }),
      });
      const data = (await res.json()) as { reply?: string; packs?: ChatPackCard[]; error?: string };
      setMessages([
        ...next,
        {
          role: "assistant",
          content: data.reply ?? data.error ?? "Une erreur est survenue. Veuillez réessayer.",
          packs: data.packs,
        },
      ]);
    } catch {
      setMessages([
        ...next,
        { role: "assistant", content: "Problème de connexion. Veuillez réessayer dans un moment." },
      ]);
    } finally {
      setPending(false);
    }
  }

  if (!open) {
    return (
      <div className="fixed right-4 bottom-4 z-40 sm:right-6 sm:bottom-6">
        <button
          type="button"
          onClick={() => setOpen(true)}
          aria-label={`Discuter avec ${CHATBOT_NAME}, l'assistant du studio`}
          className="group flex items-center gap-3 rounded-full bg-primary py-2 pr-5 pl-2 text-primary-foreground shadow-lg transition-transform hover:-translate-y-0.5 focus-visible:ring-3 focus-visible:ring-ring/50 focus-visible:outline-none"
        >
          <Avatar className="size-9 ring-2 ring-white/30" />
          <span className="text-left leading-tight">
            <span className="block text-sm font-semibold">Discuter avec {CHATBOT_NAME}</span>
            <span className="block text-[0.7rem] opacity-75">Choisissez votre pack</span>
          </span>
        </button>
      </div>
    );
  }

  return (
    <div className="fixed right-4 bottom-4 z-40 sm:right-6 sm:bottom-6">
      <section
        aria-label={`Assistant ${CHATBOT_NAME}`}
        className="flex h-[36rem] max-h-[85dvh] w-[calc(100vw-2rem)] flex-col overflow-hidden rounded-2xl bg-background shadow-2xl ring-1 ring-border sm:w-[26rem]"
      >
        <header className="flex items-center gap-3 bg-gradient-to-r from-ai to-primary px-4 py-3 text-white">
          <Avatar className="size-10 bg-white/20 ring-2 ring-white/30" />
          <div className="min-w-0 flex-1 leading-tight">
            <h2 className="flex items-center gap-2 text-base font-semibold">
              {CHATBOT_NAME}
              <span className="inline-flex items-center gap-1 rounded-full bg-white/20 px-1.5 py-0.5 text-[0.6rem] font-semibold">
                <Sparkles className="size-2.5" aria-hidden /> IA
              </span>
            </h2>
            <p className="flex items-center gap-1.5 text-xs opacity-85">
              <span className="size-1.5 rounded-full bg-emerald-300" aria-hidden />
              {CHATBOT_ROLE}
            </p>
          </div>
          {messages.length > 0 && (
            <button
              type="button"
              onClick={() => setMessages([])}
              aria-label="Nouvelle conversation"
              title="Nouvelle conversation"
              className="rounded-md p-1.5 hover:bg-white/15"
            >
              <RotateCcw className="size-4" aria-hidden />
            </button>
          )}
          <button
            type="button"
            onClick={() => setOpen(false)}
            aria-label="Fermer l'assistant"
            className="rounded-md p-1.5 hover:bg-white/15"
          >
            <X className="size-4" aria-hidden />
          </button>
        </header>

        <div
          className="flex-1 space-y-4 overflow-y-auto bg-muted/30 px-4 py-4 text-sm"
          aria-live="polite"
          aria-label="Historique de la conversation"
        >
          <div className="flex items-end gap-2">
            <Avatar className="size-6" />
            <p className="max-w-[85%] rounded-2xl rounded-bl-sm bg-card px-3 py-2 text-foreground shadow-sm ring-1 ring-border">
              {WELCOME}
            </p>
          </div>

          {messages.length === 0 && (
            <div className="flex flex-wrap gap-2 pl-8" role="list" aria-label="Suggestions">
              {SUGGESTIONS.map((s) => (
                <button
                  key={s}
                  type="button"
                  role="listitem"
                  onClick={() => send(s)}
                  className="rounded-full bg-ai-soft px-3 py-1.5 text-xs text-ai-text ring-1 ring-ai/25 transition-colors hover:bg-ai-soft/60"
                >
                  {s}
                </button>
              ))}
            </div>
          )}

          {messages.map((m, i) =>
            m.role === "user" ? (
              <div key={i} className="flex justify-end">
                <p className="max-w-[85%] rounded-2xl rounded-br-sm bg-primary px-3 py-2 text-primary-foreground">
                  {m.content}
                </p>
              </div>
            ) : (
              <div key={i} className="space-y-2">
                <div className="flex items-end gap-2">
                  <Avatar className="size-6" />
                  <p className="max-w-[85%] rounded-2xl rounded-bl-sm bg-card px-3 py-2 leading-relaxed whitespace-pre-line text-foreground shadow-sm ring-1 ring-border">
                    {m.content}
                  </p>
                </div>
                {m.packs && m.packs.length > 0 && (
                  <div
                    className="-mx-4 flex snap-x snap-mandatory gap-3 overflow-x-auto px-4 pb-2 pl-12"
                    role="list"
                    aria-label="Packs évoqués"
                  >
                    {m.packs.map((p) => (
                      <PackCard key={p.id} pack={p} bookHref={bookHref} />
                    ))}
                  </div>
                )}
              </div>
            ),
          )}

          {pending && <TypingDots />}
          <div ref={endRef} aria-hidden />
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            void send(input);
          }}
          className="flex items-center gap-2 border-t bg-background p-3"
        >
          <label htmlFor="chat-input" className="sr-only">
            Votre message
          </label>
          <input
            id="chat-input"
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            maxLength={600}
            autoComplete="off"
            placeholder={`Écrire à ${CHATBOT_NAME}…`}
            className="h-10 flex-1 rounded-full border border-input bg-muted/40 px-4 text-sm outline-none focus-visible:ring-3 focus-visible:ring-ring/50"
          />
          <Button
            type="submit"
            size="icon"
            className="rounded-full"
            disabled={pending || !input.trim()}
            aria-label="Envoyer"
          >
            <Send aria-hidden />
          </Button>
        </form>
        <p className="bg-background px-4 pb-2 text-center text-[0.65rem] text-muted-foreground">
          {CHATBOT_NAME} est une IA : le studio valide chaque demande de réservation.
        </p>
      </section>
    </div>
  );
}
